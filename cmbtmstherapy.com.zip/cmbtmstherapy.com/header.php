<!doctype html>

<html class="no-js" lang="zxx">
   
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title> </title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-YKG16NXKN6"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());

      gtag('config', 'G-YKG16NXKN6');
    </script>
        <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.png">     

		<!-- CSS here -->

        <link rel="stylesheet" href="assets/css/preloader.css">

        <link rel="stylesheet" href="assets/css/bootstrap.min.css">

        <link rel="stylesheet" href="assets/css/slick.css">

        <link rel="stylesheet" href="assets/css/metisMenu.css">

        <link rel="stylesheet" href="assets/css/owl.carousel.min.css">

        <link rel="stylesheet" href="assets/css/animate.min.css">

        <link rel="stylesheet" href="assets/css/jquery.fancybox.min.css">

        <link rel="stylesheet" href="assets/css/all.min.css">

        <link rel="stylesheet" href="assets/css/flaticon.css">

        <link rel="stylesheet" href="assets/css/nice-select.css">

        <link rel="stylesheet" href="assets/css/default.css">

        <link rel="stylesheet" href="assets/css/style.css">

        <link rel="stylesheet" href="assets/css/custom.css">

    </head>

    <body>

        <!-- Add your site or application content here -->  

        <!-- pre loader area start -->

        <!--  <div id="loading">

            <div id="loading-center">

                <div id="loading-center-absolute">

                    <div class="object" id="object_one"></div>

                    <div class="object" id="object_two"></div>

                    <div class="object" id="object_three"></div>

                </div>

            </div> 

        </div>
 -->
        <!-- pre loader area end -->

        <!-- header area start -->

        <header>

            <div id="header-sticky" class="header-area tranparent-header box-105">

                <div class="container-fluid">

                    <div class="row align-items-center">

                        <div class="col-xl-2 col-lg-2 col-md-3 col-sm-6 col-6">

                            <div class="logo">

                                <a href="index.php"><img src="assets/img/tms_logo2.png" alt="logo"></a>

                            </div>

                        </div>

                        <div class="col-xl-4 col-lg-7 d-none d-lg-block">

                            <!-- menu area start -->

                            <div class="main-menu">

                                <nav>

                                    <ul>

                                        <!-- <li class="has-dropdown"><a href="index.html">home</a></li> -->

                                       <!--  <li class="has-dropdown"><a href="#">about</a>

                                            <ul class="submenu">

                                                <li><a href="#">about us</a></li>

                                                 <li><a href="#">our team</a></li>

                                                <li><a href="#">Frequently Asked Questions</a></li>

                                                <li><a href="#">Insurance</a></li>

                                                <li><a href="#">Locations</a></li>

                                            </ul>

                                        </li>
 -->
                                       <!--  <li class="has-dropdown"> <a href="https://caltms.com/" target="_blank">Services</a> -->

                                          <!--   <ul class="submenu">

                                                <li><a href="#">How TMS Therapy Works</a></li>

                                                <li><a href="#">TMS Therapy Research</a></li>

                                            </ul>
 -->
                                        <!-- </li> -->

                                       <!--  <li class="has-dropdown"><a href="https://caltms.com/testimonials/" target="_blank">Testimonials</a>

                                        </li> -->

                                       <!--  <li class="has-dropdown"><a href="https://caltms.com/about-depression/" target="_blank">Depression</a>
 -->
                                           <!--  <ul class="submenu">

                                                <li><a href="contact.php">appointment</a></li>

                                            </ul> -->

                                       <!--  </li>
 -->
                                        <!-- <li class="has-dropdown"><a href="https://caltms.com/category/blog/" target="_blank">blog</a>

                                        </li> -->

                                       <!--  <li><a href="#appointment__area-2">Free Consultation</a></li> -->

                                    </ul>

                                </nav>

                            </div>

                            <!-- menu area end -->

                        </div>

                        <div class="col-xl-6 col-lg-5 col-md-9 col-sm-6 col-6">

                            <div class="header-bar info-toggle-btn f-right">

                                <span></span>

                                <span></span>

                                <span></span>

                            </div>

                            
                             <div class="header-cta f-right d-none d-sm-inline-block d-md-inline-block d-lg-none d-xl-inline-block">
                                <span class="icon flaticon-24-hours-support"><a href="tel:+16462034417">+1-646-203-4417</a></span>
                                
                            </div>
                            <div class="header-cta f-right d-none d-sm-inline-block d-md-inline-block d-lg-none d-xl-inline-block">
                                <span class="icon free-con smooth-scroll"> <a href="#appointment__area-2">Free Consultation</a></span>
                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </header>

         <!-- header area start -->



               <!-- info area start -->

        <section class="info__area transition-3">

            <div class="info__area-inner">

                <!-- side-mobile-menu start -->

                <nav class="side-mobile-menu">

                    <div class="info__close-icon text-right mb-20">

                        <button class="info-close-btn"><i class="fal fa-times"></i></button>

                    </div>

                    <ul id="mobile-menu-active">

                       <li class="has-dropdown"><a href="about-us.html">about</a>

                                            <ul class="submenu">

                                                <li><a href="about-us.html">about us</a></li>

                                                 <li><a href="team.html">our team</a></li>

                                                <li><a href="about-me.html">Frequently Asked Questions</a></li>

                                                <li><a href="about-me.html">Insurance</a></li>

                                                <li><a href="about-me.html">Locations</a></li>

                                            </ul>

                                        </li>

                         <li class="has-dropdown"> <a href="services.html">Services</a>

                                            <ul class="submenu">

                                                <li><a href="#">How Neurostar TMS Therapy Works</a></li>

                                                <li><a href="#">TMS Therapy Research</a></li>

                                                <li><a href="#">service details</a></li>TMS Therapy Research

                                            </ul>

                                        </li>

                                        <li class="has-dropdown"><a href="case.html">cases</a>

                                            <ul class="submenu">

                                                <li><a href="case.html">case </a></li>

                                                <li><a href="case-details.html">case details</a></li>

                                            </ul>

                                        </li>

                                        <li class="has-dropdown"><a href="#">Depression</a>

                                            <ul class="submenu">

                                                <li><a href="appointment.html">appointment</a></li>

                                            </ul>

                                        </li>

                                        <li class="has-dropdown"><a href="blog.html">blog</a>

                                        </li>

                                        <li><a href="contact.html">contact</a></li>

                    </ul>

                </nav>

                <!-- side-mobile-menu end -->

            </div>

        </section>

        <!-- <div class="body-overlay transition-3"></div> -->

        <!-- info area end -->