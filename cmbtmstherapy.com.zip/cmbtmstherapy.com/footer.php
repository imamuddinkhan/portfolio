 <!-- footer area start -->

        <footer>

            <div class="footer__area footer-bg">

                <div class="container-fluid">

                    

                    <div class="footer__bottom pt-60">

                        <div class="row">

                            <div class="col-xl-3 col-lg-6 col-md-6 mb-50">

                                <div class="footer__widget">

                                    <div class="footer__widget-title mb-20">

                                        <div class="logo">

                                            <a href="index.html"><img src="assets/img/tms_logo2.png" alt="logo"></a>
                                        </div>
                                    </div>

                                    <div class="footer__widget-content">
                                        <div class="footer__logo-area">
                                            <p>California Medical Behavioral Health specializes in anxiety & depression treatment using Transcranial Magnetic Stimulation (TMS) Therapy.</p>

                                           <!--  <div class="social">
                                                <h4>Follow us</h4>
                                                <ul>
                                                    <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>

                                                    <li><a href="#"><i class="fab fa-twitter"></i></a></li>

                                                    <li><a href="#"><i class="fab fa-pinterest-p"></i></a></li>

                                                    <li><a href="#"><i class="fab fa-instagram"></i></a></li>

                                                    <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                                                </ul>
                                            </div> -->
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-2 col-lg-6 col-md-6 offset-xl-1 mb-50">

                                <div class="footer__widget">

                                    <div class="footer__widget-title mb-25">

                                        <h2>Services</h2>

                                    </div>

                                    <div class="footer__widget-content">

                                        <div class="footer__services">

                                            <ul>

                                                <li class="smooth-scroll"><a href="#service-block">Anxiety Disorder</a></li>

                                                <li class="smooth-scroll"><a href="#service-block">Depression Problem</a></li>

                                                <li class="smooth-scroll"><a href="#service-block"> Counseling</a></li>

                                            </ul>

                                        </div>

                                    </div>

                                </div>

                            </div>

                            <div class="col-xl-2 col-lg-6 col-md-6 mb-50">

                                <div class="footer__widget">

                                    <div class="footer__widget-title mb-25">

                                        <h2>Contact Info</h2>

                                    </div>

                                    <div class="footer__widget-content">

                                        <div class="footer__contact-info">

                                            <ul>

                                                <li>

                                                    <div class="footer__contact-address">

                                                        <span>8770 Cuyamaca St #4, Santee, CA 92071</span>

                                                    </div>

                                                </li>

                                               <!--  <li>

                                                    <div class="footer__contact-item">

                                                        <h6>Email:</h6>

                                                        <p><a href="http://themepure.net/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="2b42454d446b494a5842485f434e464e05484446">[email&#160;protected]</a></p>

                                                    </div>

                                                </li> -->

                                                <li>

                                                    <div class="footer__contact-item">

                                                        <h6>Support:</h6>

                                                        <p>+1-646-203-4417 </p>

                                                    </div>

                                                </li>

                                            </ul>

                                        </div>

                                    </div>

                                </div>

                            </div>

                            <div class="col-xl-3 col-lg-6 col-md-6 offset-xl-1 mb-50">

                                <div class="footer__widget">

                                    <div class="footer__widget-title mb-25">

                                        <h2>Stay in Touch</h2>

                                    </div>

                                    <div class="footer__widget-content">

                                        <div class="footer__subscribe">

                                           <!--  <p>Fruitful and herb the seasons of fish saying likeness face beast cattle.</p> -->

                                            <div class="footer__subscribe-form">

                                                <form action="#">

                                                    <input type="email" placeholder="Email Address">

                                                    <button class="s-btn" type="submit"><i class="fal fa-paper-plane"></i> subscribe now</button>

                                                </form>

                                            </div>

                                        </div>

                                    </div>

                                </div>

                            </div>

                        </div>

                    </div>

                    <div class="footer__copyright">

                        <div class="row">

                            <div class="col-sm-5">
                                <div class="footer__copyright-text">
                                   <p> Sister concern company of <a href="https://caltms.com/" target="_blank"> 'CalTMS' </a></p>
                                </div>
                            </div>

                            <div class="col-sm-4">
                                <div class="footer__copyright-text">
                                    <p>Copyright © 2021 <a href="index.php"> CMB TMS Therapy</a>. All Rights Reserved.</p>
                                </div> 
                            </div>

                            <div class="col-sm-3">
                                <div class="footer__policy ">
                                  <!--   <a href="#">Terms & Condition</a> -->
                                    <a href="privacy-policy.php"> Privacy Policy</a>
                                    <!-- <a href="#">Support</a> -->
                                </div>
                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </footer>

        <!-- footer area end -->





		<!-- JS here -->

        <script src="assets/js/vendor/modernizr-3.5.0.min.js"></script>

        <script src="assets/js/vendor/jquery-1.12.4.min.js"></script>

        <script src="assets/js/vendor/waypoints.min.js"></script>

        <script src="assets/js/popper.min.js"></script>

        <script src="assets/js/bootstrap.min.js"></script>

        <script src="assets/js/metisMenu.min.js"></script>

        <script src="assets/js/slick.min.js"></script>

        <script src="assets/js/jquery.fancybox.min.js"></script>

        <script src="assets/js/isotope.pkgd.min.js"></script>

        <script src="assets/js/owl.carousel.min.js"></script>

       <!--  <script src="assets/js/ajax-form.js"></script> -->

        <script src="assets/js/jquery.nice-select.min.js"></script>

        <script src="assets/js/wow.min.js"></script>
<!-- 
        <script src="assets/js/imagesloaded.pkgd.min.js"></script> -->

       <!--  <script src="assets/js/jquery.counterup.min.js"></script> -->
               <script src="assets/js/validate.js"></script>
        <script src="assets/js/main.js"></script>


    </body>



</html> 