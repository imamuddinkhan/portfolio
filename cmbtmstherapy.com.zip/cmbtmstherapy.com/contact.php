<?php
include('header.php'); ?>
        <!-- info area start -->
        <section class="info__area transition-3">
            <div class="info__area-inner">
                <div class="info__area-wrapper info__area-wrapper-3">
                    <div class="info__close-icon text-right">
                        <button class="info-close-btn"><i class="fal fa-times"></i></button>
                    </div>
                    <div class="info__wrapper">
                        <div class="info__logo mt-25 mb-30">
                            <a href="index.html"><img src="assets/img/logo/logo.png" alt="logo"></a>
                        </div>
    
                        <div class="info__content">
                            <h4>About Us</h4>
                            <p>We must explain to you how all seds this mistakens idea off denouncing pleasures and praising pain was born and I will give you a completed accounts of the system and expound.</p>
    
                            <a href="contact.html" class="s-btn s-btn__white">Contact us</a>
                        </div>
                        <div class="info__contact">
                            <h3>contact info</h3>
                            <ul>
                                <li>
                                    <div class="icon">
                                        <i class="fal fa-map-marker-alt"></i>
                                    </div>
                                    <div class="text">
                                        <span>8770 Cuyamaca St #4, Santee, CA 92071 </span>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <i class="fal fa-phone"></i>
                                    </div>
                                    <div class="text">
                                        <span>800-985-7580</span>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <i class="fal fa-envelope-open"></i>
                                    </div>
                                    <div class="text">
                                        <span><a href="" class="__cf_email__" data-cfemail="">care@caltms.com</a></span>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- side-mobile-menu start -->
                <nav class="side-mobile-menu side-mobile-menu-3">
                    <div class="info__close-icon text-right mb-20">
                        <button class="info-close-btn"><i class="fal fa-times"></i></button>
                    </div>
                    <ul id="mobile-menu-active">
                        <li class="has-dropdown"><a href="index.html">home</a>
                            <ul class="submenu">
                                <li><a href="index.html">home style one</a></li>
                                <li><a href="index-2.html">home style two</a></li>
                                <li><a href="index-3.html">home style three</a></li>
                            </ul>
                        </li>
                        <li class="has-dropdown"><a href="about-us.html">about</a>
                            <ul class="submenu">
                                <li><a href="about-us.html">about us</a></li>
                                <li><a href="about-me.html">about me</a></li>
                            </ul>
                        </li>
                        <li class="has-dropdown"> <a href="services.html">services</a>
                            <ul class="submenu">
                                <li><a href="services.html">services</a></li>
                                <li><a href="services-details.html">service details</a></li>
                            </ul>
                        </li>
                        <li class="has-dropdown"><a href="case.html">cases</a>
                            <ul class="submenu">
                                <li><a href="case.html">case </a></li>
                                <li><a href="case-details.html">case details</a></li>
                            </ul>
                        </li>
                        <li class="has-dropdown"><a href="#">pages</a>
                            <ul class="submenu">
                                <li><a href="team.html">our team</a></li>
                                <li><a href="team-details.html">team details</a></li>
                                <li><a href="events.html">events and offers</a></li>
                                <li><a href="appointment.html">appointment</a></li>
                            </ul>
                        </li>
                        <li class="has-dropdown"><a href="blog.html">blog</a>
                            <ul class="submenu">
                                <li><a href="blog.html">blog </a></li>
                                <li><a href="blog-left-sidebar.html">blog Left Sidebar</a></li>
                                <li><a href="blog-no-sidebar.html">blog no sidebar</a></li>
                                <li><a href="blog-2-col.html">blog 2 column</a></li>
                                <li><a href="blog-2-col-mas.html">blog 2 col masonary</a></li>
                                <li><a href="blog-3-col.html">blog 3 column</a></li>
                                <li><a href="blog-3-col-mas.html">blog 3 col mas</a></li>
                                <li><a href="blog-details.html">blog details</a></li>
                                <li><a href="blog-details-left.html">details left sidebar</a></li>
                                <li><a href="blog-details-video.html">details video</a></li>
                                <li><a href="blog-details-audio.html">details audio</a></li>
                                <li><a href="blog-details-gallery.html">details gallery</a></li>
                            </ul>
                        </li>
                        <li><a href="contact.html">contact</a></li>
                    </ul>
                </nav>
                <!-- side-mobile-menu end -->
            </div>
        </section>
        <div class="body-overlay transition-3"></div>
        <!-- info area end -->

        <!-- scroll up area start -->
        <div class="scroll-up" id="scroll" style="display: none;">
            <a href="javascript:void(0);"><i class="far fa-angle-up"></i></a>
        </div>
        <!-- scroll up area end -->

        <main>

            <!-- page title area start -->
            <section class="page__title p-relative pt-200 pb-200" data-background="assets/img/page-title/page-title-7.jpg">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-12 col-lg-12 col-md-12">
                            <div class="page__title-inner text-center">
                                <div class="page__title-breadcrumb">                                 
                                        <nav aria-label="breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                                            <li class="breadcrumb-item active" aria-current="page">contact us</li>
                                        </ol>
                                        </nav>
                                </div>
                                <h1>contact us</h1>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- page title area end -->
                
            <!-- contact area start -->
            <section class="contact__area pt-120 pb-120">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-5 col-lg-5">
                            <div class="contact__info-head mb-40">
                                <div class="section__title mb-25">
                                    <div class="section__icon mb-10">
                                        <span class="section__sub-title section__sub-title-2 section__sub-title-3">Contact info</span>
                                    </div>
                                    <h1 >Have Any Questins Or Emergency Problem Contact With Us</h1>
                                </div>
                                <p>Pulvinar senectus morbi quisque nunc to towa faucibus netus etiam mone lestie nisi dis malesuada maecenas ora pretium ornare pharetra vestibulum mattis fringilla interdum cursus curae nisi pede laoreet placerat </p>
                            </div>
                        </div>
                        <div class="col-xl-6 offset-xl-1 col-lg-6 offset-lg-1">
                            <div class="contact__form">
                            <form id="contact-form" action="http://themepure.net/template/sycho-prv/sycho/assets/mail.php" method="POST">
                                    <div class="row">
                                        <div class="col-xl-6">
                                            <input name="name" class="contact__input contact__input-3 contact__input-4" type="text" placeholder="Your First Name">
                                        </div>
                                         <div class="col-xl-6">
                                            <input name="name" class="contact__input contact__input-3 contact__input-4" type="text" placeholder="Your Last Name">
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xl-6">
                                            <input name="subject" class="contact__input contact__input-3 contact__input-4" type="text" placeholder="Phone Number">
                                        </div>
                                        <div class="col-xl-6">
                                            <input name="email" class="contact__input contact__input-3 contact__input-4" type="email" placeholder="E-mail Address">
                                        </div>
                                      <!--   <div class="col-xl-6">
                                            <select class="contact__input contact__input-3 contact__input-4">
                                                <option value="">Choose Problem</option>
                                                <option value="">Option 1</option>
                                                <option value="">Option 2</option>
                                                <option value="">Option 3</option>
                                                <option value="">Option 4</option>
                                                <option value="">Option 5</option>
                                            </select>
                                        </div> -->
                                    </div>
                                    <div class="row">
                                        <div class="col-xl-12">
                                            <textarea name="message" class="contact__input contact__input-3 contact__input-4 txt-area " cols="30" rows="10" placeholder="Write Message"></textarea>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xl-12">
                                            <button class="s-btn s-btn__square" type="submit">submit message</button>
                                        </div>
                                    </div>
                                </form>
                                <p class="ajax-response"></p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- contact area end -->

            <!-- contact info area start -->
            <section class="contact__info p-relative">
                <div class="container">
                    <div class="contact__info-inner green-bg-2">
                        <div class="row">
                            <div class="col-xl-4 col-lg-4 col-md-6">
                                <div class="contact__info-item text-center text-sm-left d-sm-flex justify-content-lg-center mb-30">
                                    <div class="contact__icon mr-20">
                                        <span class="icon flaticon-house"></span>
                                    </div>
                                    <div class="contact__info-content">
                                        <h3>Our Address</h3>
                                        <span>8770 Cuyamaca St #4, Santee,</span>
                                        <span> CA 92071 </span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-4 col-lg-4 col-md-6">
                                <div class="contact__info-item text-center text-sm-left d-sm-flex justify-content-lg-center mb-30">
                                    <div class="contact__icon mr-20">
                                        <span class="icon flaticon-support-1"></span>
                                    </div>
                                    <div class="contact__info-content">
                                        <h3>Phone Number</h3>
                                        <span>800-985-7580 </span>
                                        
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-4 col-lg-4 col-md-6">
                                <div class="contact__info-item text-center text-sm-left d-sm-flex justify-content-lg-center mb-30">
                                    <div class="contact__icon mr-20">
                                        <span class="icon flaticon-email"></span>
                                    </div>
                                    <div class="contact__info-content">
                                        <h3>Email Support</h3>
                                        <span><a href="mailto:care@caltms.com">care@caltms.com</a></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- contact info area end -->

            <!-- contact map area start -->
            <!-- <section class="contact__map-area mt--120">
                <div class="container-fluid p-0">
                    <div class="row no-gutters">
                        <div class="col-xl-12">
                            <div class="contact__map">
                                <iframe src="https://maps.google.com/maps?hl=en&amp;q=Dhaka+()&amp;ie=UTF8&amp;t=&amp;z=10&amp;iwloc=B&amp;output=embed" ></iframe>
                            </div>
                        </div>
                    </div>
                </div>
            </section> -->
            <!-- contact map area end -->
        </main>

<!-- footer area start -->
<?php
include('footer.php'); ?>
