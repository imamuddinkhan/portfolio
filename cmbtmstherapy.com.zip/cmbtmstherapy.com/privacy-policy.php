<?php
include('header.php'); ?> 
        <main>
           <!-- page title area start -->
            <section class="page__title p-relative pt-150 pb-150" data-background="assets/img/page-title/page-title-7.jpg">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-12 col-lg-12 col-md-12">
                            <div class="page__title-inner text-center">
                               <!--  <div class="page__title-breadcrumb">                                 
                                        <nav aria-label="breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                            <li class="breadcrumb-item active" aria-current="page">Privacy Policy</li>
                                        </ol>
                                        </nav>
                                </div> -->
                                <h1>Privacy Policy</h1>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- page title area end -->
                
            <!-- contact area start -->
            <section class="contact__area pt-50 pb-50">
                <div class="container">
                    <div class="row">
                       <div class="col-md-12">
                        <h4>The Company </h4>
                           
                           <p> Privacy Policy </p>
                           <p> Last updated: February 24, 2020</p>
                           <p> This Privacy Policy describes Our policies and procedures on the collection, use and disclosure of Your information when You use the Service and tells You about Your privacy rights and how the law protects You. <br>
                           We use Your Personal data to provide and improve the Service. By using the Service, You agree to the collection and use of information in accordance with this Privacy Policy. <br>
                           Interpretation and Definitions <br>
                           Interpretation <br>
                           The words of which the initial letter is capitalized have meanings defined under the following conditions. <br>
                           The following definitions shall have the same meaning regardless of whether they appear in singular or in plural. <br></p>
                           <h4> Definitions <h4>
                           <h6> For the purposes of this Privacy Policy:</h6>
                           <p> You means the individual accessing or using the Service, or the company, or other legal entity on behalf of which such individual is accessing or using the Service, as applicable.</p>
                           <p> Company (referred to as either “the Company”, “We”, “Us” or “Our” in this Agreement) refers to California Behavioral Health – 8770 Cuyamaca St STE 4 Santee, CA 92071</p>
                           <p> Affiliate means an entity that controls, is controlled by or is under common control with a party, where “control” means ownership of 50% or more of the shares, equity interest or other securities entitled to vote for election of directors or other managing authority. </p>
                           <p> Account means a unique account created for You to access our Service or parts of our Service. </p>
                           <p>Website refers to California Medical Behavioral Health, accessible from CalTMS.com</p>
                           <h4> Service refers to the Website. </h4>
                           <h6> Country refers to United States </h6>
                           <p> Service Provider means any natural or legal person who processes the data on behalf of the Company. It refers to third-party companies or individuals employed by the Company to facilitate the Service, to provide the Service on behalf of the Company, to perform services related to the Service or to assist the Company in analyzing how the Service is used. </p>
                           <p> Third-party Social Media Service refers to any website or any social network website through which a User can log in or create an account to use the Service.</p>
                           <p> Personal Data is any information that relates to an identified or identifiable individual.</p>
                           <p> Cookies are small files that are placed on Your computer, mobile device or any other device by a website, containing the details of Your browsing history on that website among its many uses.</p>

                       </div>
                    </div>
                </div>
            </section>
            <!-- contact area end -->

           
        </main>

<!-- footer area start -->
<?php
include('footer.php'); ?>
