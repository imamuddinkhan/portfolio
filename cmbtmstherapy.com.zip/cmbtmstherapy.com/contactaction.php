<html>
<head>
</head>
<body>
   
<?php 

$name = $_POST['name'];
 $number = $_POST["number"];
$email = $_POST["email"];
$message = $_POST["message"];
// $recipient = "info@cmbtmstherapy.com";
// $mailheader = "From: $email \r\n";
//$EmailTo = "support@compendiousmedworks.com";
$EmailTo = "info@cmbtmstherapy.com,imamuddincmw@gmail.com";
$Subject = "CMB TMS New Appointment Message";

// Always set content-type when sending HTML email
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// More headers
// $headers .= 'From: <imamuddincmw@gmail.com>' . "\r\n";
$headers = 'From: CMB TMS Therapy info@cmbtmstherapy.com' . "\r\n" ;
    $headers .='Reply-To: '. $to . "\r\n" ;
    //$headers .='X-Mailer: PHP/' . phpversion();
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-type: text/html; charset=iso-8859-1\r\n";  

// prepare email body text
$Body = "";
$Body .= "Name: ";
$Body .= $name;
$Body .= "<br>";
$Body .= "number: ";
$Body .= $number;
$Body .= "<br>";
$Body .= "Email: ";
$Body .= $email;
$Body .= "<br>";
$Body .= "Message: ";
$Body .= $message;
$Body .= "<br>";
mail($EmailTo, $Subject, $Body, $headers) or die("Error!");


echo "<p> <font color=green size='4pt'> Thank you for your submission. Our team will call you within 24 hours.</font></p>";

?>
<script>
    setTimeout(function () {    
    window.location.href = 'https://www.cmbtmstherapy.com'; 
},3000);
</script>
 </body>
</html>