<?php
include('header.php'); ?>
      <!-- scroll up area start -->
        <div class="scroll-up" id="scroll" style="display: none;">
            <a href="javascript:void(0);"><i class="far fa-angle-up"></i></a>
        </div>
        <!-- scroll up area end -->
        <main>
            <!-- slider area start -->
            <div class="slider-area p-relative">
                <!-- <div class="slider-arrow p-absolute bounce smooth-scroll">
                    <a href="#appointment__area-2" class="slider-arrow-btn"><i class="fal fa-long-arrow-down"></i></a>
                </div> -->
                <div class="slider-active slider-active-2">
                    <div class="single-slider slider-height-2 slider-overlay p-relative slider-height d-flex align-items-center" data-background="assets/img/slider-1.jpg">
                        <div class="container">
                            <div class="row align-items-center">
                                <div class="col-xl-12 text-center">
                                    <div class="slider-content slider-content-2">
                                        <span data-animation="fadeInUp" data-delay=".2s">MOST TRUSTED NON-DRUG THERAPY</span>
                                        <h2 data-animation="fadeInUp" data-delay=".4s">Your access to instant professional care online </h2>
                                        <!-- <p data-animation="fadeInUp" data-delay=".6s">Mental illness is not contagious you won’t catch it by being kind</p>
                                        <div class="banner-list">
                                        <p><i class="fa fa-check"></i> No side effects </p>
                                        <p><i class="fa fa-check"></i> Safe, effective & FDA-approved </p>
                                        <p><i class="fa fa-check"></i> Covered by most insurances </p>
                                        <p>(including Medicare & Tricare)  </p> -->
                                        </div>
                                        <div class="slider-btn smooth-scroll" data-animation="fadeInUp" data-delay=".8s">
                                            <a href="#appointment__area-2" class="s-btn s-btn-sm s-btn__square"> Book Your Consultation </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                   <!--  <div class="single-slider slider-height-2 slider-overlay p-relative slider-height d-flex align-items-center" data-background="assets/img/slider/02/slider-2.jpg">
                        <div class="container">
                            <div class="row align-items-center">
                                <div class="col-xl-9">
                                    <div class="slider-content slider-content-2">
                                        <span data-animation="fadeInUp" data-delay=".2s">Every depression solution</span>
                                        <h2 data-animation="fadeInUp" data-delay=".4s">Best Psychologist Makes Excellent </h2>
                                        <p data-animation="fadeInUp" data-delay=".6s">Mental illness is not contagious you won’t catch it by being kind</p>
                                        <div class="slider-btn" data-animation="fadeInUp" data-delay=".8s">
                                            <a href="appointment.html" class="s-btn s-btn-sm s-btn__square">make appointment</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> -->
                    <<!-- div class="single-slider slider-height-2 slider-overlay p-relative slider-height d-flex align-items-center" data-background="assets/img/slider/02/slider-3.jpg">
                        <div class="container">
                            <div class="row align-items-center">
                                <div class="col-xl-9">
                                    <div class="slider-content slider-content-2">
                                        <span data-animation="fadeInUp" data-delay=".2s">Every depression solution</span>
                                        <h2 data-animation="fadeInUp" data-delay=".4s">Best Psychologist Makes Excellent </h2>
                                        <p data-animation="fadeInUp" data-delay=".6s">Mental illness is not contagious you won’t catch it by being kind</p>
                                        <div class="slider-btn" data-animation="fadeInUp" data-delay=".8s">
                                            <a href="appointment.html" class="s-btn s-btn-sm s-btn__square">make appointment</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> -->
                </div>
            </div>
            <!-- slider area end -->
            
            <!-- appointment area start -->
            <section id="appointment__area-2" class="appointment__area appointment__area-2 pt-60 pb-60 box-105">
                <div class="container-fluid">
                    <div class="appointment__area-inner-2 white-bg p-relative">
                        <div class="row">
                            <div class="col-xl-7 col-lg-7">
                                <div class="appointment__form-wrapper mr-65">
                                    <h1>Get An Appointment</h1>
                                    <div class="appointment__form-inner">
                                        <form action="contactaction.php" method="post" class="php-appointment-form">
                                            <div class="form-group">
                                                <input type="text" name="name" placeholder="Your Name" data-rule="required" data-msg="Please enter your name.">
                                                 <div class="validate"></div>
                                            </div>
                                            <div class="form-group">
                                                <input type="text" name="number" placeholder="Contact Number" data-rule="phone" data-msg="Please enter your valid contact number.">
                                                 <div class="validate"></div>
                                            </div>
                                            <div class="form-group">
                                                <input type="email" name="email" placeholder="Email Address" data-rule="email" data-msg="Please enter your valid email address.">
                                                 <div class="validate"></div>
                                            </div>
                                            <div class="form-group">
                                                <textarea name="message" cols="30" rows="10" placeholder="Write Message" data-rule="required" data-msg="Please enter your message."></textarea>
                                                 <div class="validate"></div>
                                            </div>
                                            <div class="col-12 form-group">
                                                <div class="loading"></div>
                                                <div class="error-message"></div>
                                                <div class="sent-message">Your message has been sent. Thank you!</div>
                                            </div>
                                            <button class="sub-btn" type="submit">GET A CALL BACK</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <!-- <div class="col-xl-4 col-lg-6">
                                <div class="appointment__award">
                                    <div class="section__title award__title mb-40">
                                        <div class="section__icon mb-10">
                                            <span class="section__sub-title section__sub-title-2">International Award</span>
                                        </div>
                                        <h1 class="mb-100">The Best Achievements in Recognition of Our Work</h1>
                                    </div>

                                    <div class="appointment__award-list">
                                        <div class="single-award d-flex mb-50">
                                            <div class="award-icon mr-30">
                                                <img src="assets/img/award/list/award-list-1.png" alt="award-1">
                                            </div>
                                            <div class="award-text">
                                                <h3>National Award (2005)</h3>
                                               
                                            </div>
                                        </div>
                                        <div class="single-award d-flex mb-50">
                                            <div class="award-icon mr-30">
                                                <img src="assets/img/award/list/award-list-2.png" alt="award-1">
                                            </div>
                                            <div class="award-text">
                                                <h3>National Award (2007)</h3>
                                               
                                            </div>
                                        </div>
                                        <div class="single-award d-flex mb-50">
                                            <div class="award-icon mr-30">
                                                <img src="assets/img/award/list/award-list-3.png" alt="award-1">
                                            </div>
                                            <div class="award-text">
                                                <h3>National Award (2009)</h3>
                                               
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div> -->
                            <div class="col-xl-5 col-lg-5">
                                <div class="appointment__mission">
                                    <div class="appointment__mission-thumb p-relative w-img">
                                        <img src="assets/img/appointment-mission.jpg" alt="appointment-mission">
                                        <div class="play-icon p-absolute">
                                            <a href="https://youtu.be/M8elRfRgbI8" data-fancybox class="play-btn"><i class="fas fa-play"></i></a>
                                        </div>
                                    </div>
                                    <div class="appointment__mission-text">
                                        <h3>Our Mission:</h3>
                                        <p>At California Medical Behavioral TMS Therapy, we believe that there is no “one-size fits all” approach to treating depression. While anti-depressants and psychotherapy can be viable treatment options for some individuals, they do not work for everyone. </p>
                                        <p>TMS Therapy targets an area of the brain called the left dorsolateral prefrontal cortex, which is involved in mood regulation and has been shown to be under-active in individuals struggling from depression.</p>
                                        <p>We know it can be overwhelming when deciding between treatment options for yourself or a loved one. That is why we are committed to helping you every step of the way. </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- appointment area end -->

            <!-- team area start -->
            <section class="team__area pb-60">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-8 offset-xl-2 col-lg-10 offset-lg-1">
                            <div class="section__title mb-65 text-center">
                                <div class="section__icon mb-10">
                                    <span class="section__sub-title section__sub-title-2">MEET YOUR THERAPISTS </span>
                                </div>
                                <h1 class="mb-100"> The most trusted and experienced doctors in the USA </h1>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xl-4 col-lg-4 col-md-6">
                            <div class="team__item mb-30">
                                <div class="team__thumb w-img fix p-relative">
                                    <img class="transition-3" src="assets/img/team/drsmitchauhan.jpg" alt="team-1">
                                    <!-- <div class="team__social social pink-soft-bg p-absolute transition-3">
                                        <ul>
                                            <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                            <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                            <li><a href="#"><i class="fab fa-pinterest-p"></i></a></li>
                                            <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                                        </ul>
                                    </div> -->
                                </div>
                                <div class="team__content text-center white-bg transition-3">
                                    <div class="team__name">
                                        <h3>Smit Chauhan</h3>
                                        <span>M.D.</span>
                                    </div>
                                    <div class="team__info">
                                        <!-- <p><a href="http://themepure.net/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="d9abb0aaadb6a9b1bcabbe99beb4b8b0b5f7bab6b4">[email&#160;protected]</a></p> -->
                                       <!--  <p>800-985-7580</p> -->
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-4 col-md-6">
                            <div class="team__item mb-30">
                                <div class="team__thumb w-img fix p-relative">
                                    <img class="transition-3" src="assets/img/team/DrMahipalChaudh.jpg" alt="team-1">
                                   <!--  <div class="team__social social pink-soft-bg p-absolute transition-3">
                                        <ul>
                                            <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                            <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                            <li><a href="#"><i class="fab fa-pinterest-p"></i></a></li>
                                            <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                                        </ul>
                                    </div> -->
                                </div>
                                <div class="team__content text-center white-bg transition-3">
                                    <div class="team__name">
                                        <h3>Mahipal Chaudhri</h3>
                                        <span> MBBS, M.D.</span>
                                    </div>
                                    <!-- <div class="team__info">
                                        <p>800-985-7580</p>
                                    </div> -->
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-4 col-md-6">
                            <div class="team__item mb-30">
                                <div class="team__thumb w-img fix p-relative">
                                    <img class="transition-3" src="assets/img/team/Dr_Yash_Profile.jpg" alt="team-1">
                                    <!-- <div class="team__social social pink-soft-bg p-absolute transition-3">
                                        <ul>
                                            <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                            <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                            <li><a href="#"><i class="fab fa-pinterest-p"></i></a></li>
                                            <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                                        </ul>
                                    </div> -->
                                </div>
                                <div class="team__content text-center white-bg transition-3">
                                    <div class="team__name">
                                       
                                         <h3>Yashwant Chaudhri</h3>
                                        <span>M.D.</span>
                                    </div>
                                    <!-- <div class="team__info">
                                        <p>800-985-7580</p>
                                    </div> -->
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </section>
            <!-- team area end -->

            
            <!-- about area start -->
            <section class="about__area-2 mb-60 box-105 p-relative">
                <div class="container-fluid">
                    <div class="about__inner p-relative">
                        <div class="about__bg-img p-absolute" data-background="assets/img/about/about-2.jpg"></div>
                        <div class="row">
                            <div class="col-xl-6 offset-xl-6">
                                <div class="about__content-wrapper about__content-wrapper-2 pt-20 pl-85">
                                    <div class="section__title mb-30">
                                        <div class="section__icon mb-10">
                                            <span class="section__sub-title section__sub-title-2"> WELCOME TO CMB TMS THERAPY </span>
                                        </div>
                                        <h1 class="mb-100">We take care of patients like newly born children</h1>
                                    </div>

                                    <p>For more than 35 years, California Medical Behavioral Health providers have served as leaders in behavioral and mental health care. We understand that physical, mental, financial, emotional, social, and spiritual well-being are interconnected. That’s why we don’t just focus on mental health, we focus on the whole self.</p>

                                    <div class="about__info-2 d-sm-flex mb-60">
                                        <div class="about__info-experience white-bg mr-40">
                                            <h1>35+ Years Professional Experience</h1>
                                        </div>
                                        <p>We are currently accepting new TMS patients at our National City, Santee and Oceanside locations, and are one of a select few providers in San Diego, CA offering Transcranial Magnetic Stimulation (TMS) for patients with major depression. </p>
                                    </div>
                                    <div class="about-bottom d-sm-flex">
                                        <div class="about-author mr-30 mb-30">
                                            <img src="assets/img/about/chaturvedi.jpg" alt="">
                                            <div class="ab-author">
                                                <h3>Yashwant Chaudhri</h3>
                                                <span>CEO, CMB TMS Therapy</span>
                                            </div>
                                        </div>
                                        <div class="about-btn mr-40 mb-30">
                                            <a href="https://caltms.com/" class="s-btn s-btn__square s-btn__square-2" tabindex="0">more about us</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- about area start -->

            <!-- services area start -->
            <section class="services__area-2 pb-60" id="service-block">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-8 offset-xl-2 col-lg-10 offset-lg-1">
                            <div class="section__title mb-65 text-center">
                               
                                <h1 class="mb-100">OUR PROFESSIONAL PSYCHOLOGY SERVICES </h1>
                                 <div class="section__icon mb-10">
                                    <span class="section__sub-title section__sub-title-2">It’s time to heal</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                       <!--  <div class="col-xl-4 col-lg-4 col-md-6">
                            <div class="services__item-2 transition-3 mb-30 text-center white-bg">
                                <div class="services__icon mb-30">
                                    <span class="icon flaticon-relationship"></span>
                                </div>
                                <div class="services__content-2 transition-3">
                                    <h3><a href="">Personal Meeting</a></h3>
                                    <p>Blandit fauce bus perce viverra sem rutrum vulputate came faucibus condim entum imperdiet in velarus lacinia place tortor</p>

                                    <a href="" class="link-btn">Read details</a>
                                </div>
                            </div>
                        </div> -->
                       <!--  <div class="col-xl-4 col-lg-4 col-md-6">
                            <div class="services__item-2 transition-3 mb-30 text-center white-bg">
                                <div class="services__icon mb-30">
                                    <span class="icon flaticon-family"></span>
                                </div>
                                <div class="services__content-2 transition-3">
                                    <h3><a href="#">Family Counseling</a></h3>
                                    <p>Blandit fauce bus perce viverra sem rutrum vulputate came faucibus condim entum imperdiet in velarus lacinia place tortor</p>

                                    <a href="https://caltms.com/" class="link-btn">Read details</a>
                                </div>
                            </div>
                        </div> -->
                        <div class="col-xl-4 col-lg-4 col-md-6">
                            <div class="services__item-2 transition-3 mb-30 text-center white-bg">
                                <div class="services__icon mb-30">
                                    <span class="icon flaticon-psychosis"></span>
                                </div>
                                <div class="services__content-2 transition-3">
                                    <h3 class="smooth-scroll"><a href="#appointment__area-2">Anxiety Disorder</a></h3>
                                    <!-- <p>Blandit fauce bus perce viverra sem rutrum vulputate came faucibus condim entum imperdiet in velarus lacinia place tortor</p> -->

                                    <!-- <a href="https://caltms.com/" class="link-btn">Read details</a> -->
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-4 col-md-6">
                            <div class="services__item-2 transition-3 mb-30 text-center white-bg">
                                <div class="services__icon mb-30">
                                    <span class="icon flaticon-sweat"></span>
                                </div>
                                <div class="services__content-2 transition-3">
                                    <h3 class="smooth-scroll"><a href="#appointment__area-2">Depression Problem</a></h3>
                                    <!-- <p>Blandit fauce bus perce viverra sem rutrum vulputate came faucibus condim entum imperdiet in velarus lacinia place tortor</p> -->

                                    <!-- <a href="https://caltms.com/" class="link-btn">Read details</a> -->
                                </div>
                            </div>
                        </div>
                       <!--  <div class="col-xl-4 col-lg-4 col-md-6">
                            <div class="services__item-2 transition-3 mb-30 text-center white-bg">
                                <div class="services__icon mb-30">
                                    <span class="icon flaticon-heart"></span>
                                </div>
                                <div class="services__content-2 transition-3">
                                    <h3><a href="#">Dating & Relation</a></h3>
                                    <p>Blandit fauce bus perce viverra sem rutrum vulputate came faucibus condim entum imperdiet in velarus lacinia place tortor</p>

                                    <a href="https://caltms.com/" class="link-btn">Read details</a>
                                </div>
                            </div>
                        </div> -->
                        <div class="col-xl-4 col-lg-4 col-md-6">
                            <div class="services__item-2 transition-3 mb-30 text-center white-bg">
                                <div class="services__icon mb-30">
                                    <span class="icon flaticon-relationship"></span>   
                                </div>
                                <div class="services__content-2 transition-3">
                                    <h3 class="smooth-scroll"><a href="#appointment__area-2"> Counseling</a></h3>
                                    <!-- <p>Blandit fauce bus perce viverra sem rutrum vulputate came faucibus condim entum imperdiet in velarus lacinia place tortor</p> -->
                                    <!-- <a href="https://caltms.com/" class="link-btn">Read details</a> -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- services area end -->

            <!-- why area start -->
            <section class="why__area p-relative grey-bg-3 box-105 pt-40 pb-40">
                <div class="why__bg p-absolute" data-background="assets/img/why-img.jpg"></div>
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-xl-7">
                            <div class="why__wrapper">
                                <div class="section__title mb-60 pr-50">
                                    <div class="section__icon mb-10">
                                        <span class="section__sub-title section__sub-title-2">OUR FEATURES</span>
                                    </div>
                                    <h1 class="mb-100">Why we are the best?</h1>
                                </div>
                                <!-- <p>Lorem ipsum dolor sit amet consectetur adipisicing to elit sedient for dole there eiusmod 
                                    labore dolore magna aliqua denim ad minim veniam quis nostrud exerctation ullamco laibor nisi above murli aliquip</p> -->

                                <div class="why__list pr-35">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="why__item d-flex pr-40 mb-70">
                                                <div class="why__icon mr-30">
                                                    <span class="icon flaticon-happy"></span>
                                                </div>
                                                <div class="why__text">
                                                    <h3>Safe & Effective</h3>
                                                    <p> As an FDA-approved treatment, TMS Therapy has undergone rigorous clinical trials to determine its safety and efficacy.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="why__item d-flex pr-40 mb-70">
                                                <div class="why__icon mr-30">
                                                    <span class="icon flaticon-24-hours-support"></span>
                                                </div>
                                                <div class="why__text">
                                                    <h3>In-Office Treatment</h3>
                                                    <p>TMS Therapy is performed 5 days per week, for a period of 4-6 weeks in a psychiatrist's office.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="why__item d-flex pr-40 mb-70">
                                                <div class="why__icon mr-30">
                                                    <span class="icon flaticon-psychologist"></span>
                                                </div>
                                                <div class="why__text">
                                                    <h3>No Side Effects</h3>
                                                    <p>TMS Therapy is a non-drug, non-systemic treatment option, so it does not have the same side effects that are associated with traditional anti-depressant medications.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="why__item d-flex pr-40 mb-70">
                                                <div class="why__icon mr-30">
                                                    <span class="icon flaticon-happy"></span>
                                                </div>
                                                <div class="why__text">
                                                    <h3>Minimal Discomfort</h3>
                                                    <p>Temporary pain or discomfort at or near the treatment site during TMS Therapy is common, but typically resolves within the first week.</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- why area end -->

            <!-- client area start -->
            
            <!-- client area end -->

            <!-- case area start -->
            <!-- <section class="case__area pt-60 pb-60 mb-345 pink-soft-bg">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-8 offset-xl-2">
                            <div class="section__title mb-80 text-center">
                                <div class="section__icon mb-10">
                                    <span class="section__sub-title section__sub-title-2">affordable Services</span>
                                </div>
                                <h1 class="mb-100">Explore Case Studies</h1>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xl-4 col-lg-4 col-md-6">
                            <div class="case__item-2 mb--328 p-relative">
                                <div class="case__thumb-2 w-img">
                                    <img src="assets/img/case/02/case-01.jpg" alt="case-01">
                                </div>
                                <div class="case__content-2 transition-3 grey-bg-3 p-relative">
                                    <h3><a href="https://caltms.com/">Dating & Relationship</a></h3>
                                    <p>Fames nostra nascetur dis id pellentree at ligula auctor metus semper convalis ligula augue natoque </p>
                                    <a href="https://caltms.com/" class="link-btn">explore more</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-4 col-md-6">
                            <div class="case__item-2 mb--328 p-relative">
                                <div class="case__thumb-2 w-img">
                                    <img src="assets/img/case/02/case-02.jpg" alt="case-01">
                                </div>
                                <div class="case__content-2 transition-3 grey-bg-3 p-relative">
                                    <h3><a href="https://caltms.com/">Depression Problem</a></h3>
                                    <p>Fames nostra nascetur dis id pellentree at ligula auctor metus semper convalis ligula augue natoque </p>
                                    <a href="https://caltms.com/" class="link-btn">explore more</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-4 col-md-6">
                            <div class="case__item-2 mb--328 p-relative">
                                <div class="case__thumb-2 w-img">
                                    <img src="assets/img/case/02/case-03.jpg" alt="case-01">
                                </div>
                                <div class="case__content-2 transition-3 grey-bg-3 p-relative">
                                    <h3><a href="https://caltms.com/">Couple Counseling</a></h3>
                                    <p>Fames nostra nascetur dis id pellentree at ligula auctor metus semper convalis ligula augue natoque </p>
                                    <a href="https://caltms.com/" class="link-btn">explore more</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section> -->
            <!-- case area end -->

            <!-- testimonial area start -->
            <section class="testimonial__area-2 pt-60 pb-60">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-7 col-lg-9">
                            <div class="section__title mb-65">
                                <div class="section__icon mb-10">
                                    <span class="section__sub-title section__sub-title-2">TESTIMONIALS</span>
                                </div>
                                <h1 class="mb-100">Our Happy Patients</h1>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="testimonial__slider-2">
                                <div class="testimonial__slider-2-active owl-carousel">
                                    <div class="testimonial__item-2">
                                        <div class="testimonial__item-inner green-bg-2 p-relative fix">
                                            <p>“When I sought out TMS Therapy as a treatment option for my depression, I felt as though I had tried (and failed) literally everything. Over the years, I have tried at least a dozen different anti-depressant medications and seen countless therapists with little to no improvement in my symptoms. </p>

                                            <div class="testimonial__person testimonial__person-2 d-flex align-items-center">
                                                <!-- <div class="testimonial__avater">
                                                    <img src="assets/img/testimonial/person-1.png" alt="">
                                                </div> -->
                                                <div class="testimonial__info">
                                                    <h3>Alex </h3>
                                                    <span> TMS Patient</span>
                                                </div>
                                            </div>

                                            <div class="testimonial__quote-2 p-absolute">
                                                <span class="icon flaticon-quotation"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="testimonial__item-2">
                                        <div class="testimonial__item-inner green-bg-2 p-relative fix">
                                            <p>“I had the good fortune to have Lexi as my TMS Technician for nearly every one of my TMS Therapy sessions. I, like most, dread going in to “the doctor’s office”. However, Lexi truly made the experience so wonderful for me each day. Her attention to detail.</p>

                                            <div class="testimonial__person testimonial__person-2 d-flex align-items-center">
                                                <!-- <div class="testimonial__avater">
                                                    <img src="assets/img/testimonial/person-2.png" alt="">
                                                </div> -->
                                                <div class="testimonial__info">
                                                    <h3>Kevin </h3>
                                                    <span>TMS Patient</span>
                                                </div>
                                            </div>

                                            <div class="testimonial__quote-2 p-absolute">
                                                <span class="icon flaticon-quotation"></span>
                                            </div>
                                        </div>
                                    </div>
                                   <!--  <div class="testimonial__item-2">
                                        <div class="testimonial__item-inner green-bg-2 p-relative fix">
                                            <p>Pede non libero iaculis nunc for tempus an luctus tristique fringilla euismod praesent. Taciti massa to nam feugiat laoreet consectetuer lacus. Velit idolet egestas hendrerit bibendum commodo fermentum</p>

                                            <div class="testimonial__person testimonial__person-2 d-flex align-items-center">
                                                <div class="testimonial__avater">
                                                    <img src="assets/img/testimonial/person-3.png" alt="">
                                                </div>
                                                <div class="testimonial__info">
                                                    <h3>Zimmy Carter</h3>
                                                    <span>Creative Director</span>
                                                </div>
                                            </div>

                                            <div class="testimonial__quote-2 p-absolute">
                                                <span class="icon flaticon-quotation"></span>
                                            </div>
                                        </div>
                                    </div> -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- testimonial area end -->

            <!-- faq area start -->
            <section class="faq__area p-relative box-105 pink-soft-bg pt-110 pb-120">
                <div class="faq__bg p-absolute" data-background="assets/img/faq/faq-img.jpg"></div>
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-xl-6 col-lg-12">
                            <div class="faq__wrapper pr-140">
                                <div class="section__title mb-30">
                                    <div class="section__icon mb-10">
                                        <span class="section__sub-title section__sub-title-2">FAQS</span>
                                    </div>
                                    <h1 class="mb-100">Ask us anything!</h1>
                                </div>
                                <div class="faq__inner mr-30">
                                    <div id="accordion">
                                        <div class="card">
                                          <div class="card-header white-bg" id="headingOne">
                                            <h5 class="mb-0">
                                              <button class="faq-accordion-btn collapsed" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                                                What is TMS Therapy?
                                              </button>
                                            </h5>
                                          </div>
                                      
                                          <div id="collapseOne" class="collapse " aria-labelledby="headingOne" data-parent="#accordion">
                                            <div class="card-body">
                                                Transcranial Magnetic Stimulation (TMS) Therapy, is a non-invasive, non-systemic, non-drug treatment for depression. TMS Therapy uses a targeted pulsed magnetic field, similar to the magnetic field produced by an MRI machine, to stimulate the under-active area of your brain thought to control mood.
                                            </div>
                                          </div>
                                        </div>
                                        <div class="card">
                                          <div class="card-header white-bg" id="headingTwo">
                                            <h5 class="mb-0">
                                              <button class="faq-accordion-btn" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
                                                How does TMS Therapy work?
                                              </button>
                                            </h5>
                                          </div>
                                          <div id="collapseTwo" class="collapse show" aria-labelledby="headingTwo" data-parent="#accordion">
                                            <div class="card-body">
                                                TMS Therapy uses short pulses of magnetic fields to stimulate the areas of the brain that are thought to function differently in patients with depression. The magnetic field produces an electric current in the brain that stimulates the brain cells (neurons). This results in changes in the brain that are thought to be beneficial in the treatment of depression.
                                            </div>
                                          </div>
                                        </div>
                                        <div class="card">
                                          <div class="card-header white-bg" id="headingThree">
                                            <h5 class="mb-0">
                                              <button class="faq-accordion-btn collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                                Is TMS Therapy uncomfortable?
                                              </button>
                                            </h5>
                                          </div>
                                          <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
                                            <div class="card-body">
                                                The most common side effect related to treatment is scalp pain or discomfort during treatment sessions — generally mild to moderate.

                                                If necessary, you can treat this discomfort with an over-the-counter analgesic. If these side effects persist, your doctor can temporarily reduce the strength of the magnetic field pulses being administered in order to make treatment more comfortable.

                                                Less than 5% of patients treated with TMS Therapy discontinued treatment due to side effects.
                                            </div>
                                          </div>
                                        </div>
                                        <div class="card">
                                          <div class="card-header white-bg" id="headingFour">
                                            <h5 class="mb-0">
                                              <button class="faq-accordion-btn collapsed" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                                What are the potential risks of TMS Therapy?
                                              </button>
                                            </h5>
                                          </div>
                                          <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordion">
                                            <div class="card-body">
                                                TMS Therapy is well tolerated and has been proven to be safe in clinical trials. Throughout over 10,000 active treatments performed in clinical trials, the most commonly reported side effect related to treatment was scalp pain or discomfort during treatment sessions. These side effects were generally mild to moderate, and occurred less frequently after the first week of treatment.

                                                    Over 10,000 TMS Therapy treatments were administered during clinical trials to demonstrate its safety, with no occurrence of seizures. However, there is a small risk of a seizure occurring during treatment. This risk is no greater than what has been observed with oral antidepressant medications.

                                                    While TMS Therapy has been proven effective, not all patients will benefit from it. Patients should be carefully monitored for worsening symptoms, signs or symptoms of suicidal behavior, and/or unusual behavior. Families and caregivers should also be aware of the need to observe patients and notify their treatment provider if symptoms worsen.
                                            </div>
                                          </div>
                                        </div>
                                        <div class="card">
                                          <div class="card-header white-bg" id="headingFive">
                                            <h5 class="mb-0">
                                              <button class="faq-accordion-btn collapsed" data-toggle="collapse" data-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                                                When will I begin to notice results with TMS Therapy?
                                              </button>
                                            </h5>
                                          </div>
                                          <div id="collapseFive" class="collapse" aria-labelledby="headingFive" data-parent="#accordion">
                                            <div class="card-body">
                                                The time it takes to notice results with TMS Therapy will vary patient to patient. Some patients may notice a slight improvement in their depressive symptoms after one to two weeks of treatment, while others may not have noticeable changes until weeks four or five of treatment. If it takes longer to notice improvements in your depressive symptoms compared to someone else, this does not mean that the treatment is ineffective. Ultimately, the effects of TMS Therapy are the same: relief of depressive symptoms that are long lasting.
                                            </div>
                                          </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- faq area end -->

            <!-- blog area start -->
            <section class="blog__area box-105 pt-60 pb-60">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-8 offset-xl-2">
                            <div class="section__title mb-70 text-center pl-50 pr-50">
                                <div class="section__icon mb-10">
                                    <span class="section__sub-title section__sub-title-2">popular articles</span>
                                </div>
                                <h1>Every Single Update And Recent Story From Our Blog</h1>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xl-4 col-lg-4 col-md-6">
                            <div class="blog__item mb-30">
                                <div class="blog__thumb-2 w-img fix">
                                    <img src="assets/img/blog/blog-big-1.jpg" alt="">
                                </div>
                                <div class="blog__content blog__content-2 white-bg p-relative">
                                 <!--    <div class="blog__meta blog__meta-2 fix mb-10">
                                        <span class="f-left publisher">By <a href="https://caltms.com/">admin</a></span>
                                        <span class="f-left date"><a href="https://caltms.com/">/ august 19, 2020</a></span>
                                    </div> -->
                                    <h3><a href="blog-details.php">Is TMS a permanent depression treatment?</a></h3>
                                   <!--  <div class="blog__meta blog__meta-2">
                                        <span><a href="https://caltms.com/"><i class="fas fa-tags"></i>Couple Problem</a></span>
                                        <span><a href="https://caltms.com/"><i class="far fa-comments"></i>2 Comment</a></span>
                                    </div> -->
                                </div>
                            </div>
                        </div>
                       <!--  <div class="col-xl-4 col-lg-4 col-md-6">
                            <div class="blog__item mb-30">
                                <div class="blog__thumb-2 w-img fix">
                                    <img src="assets/img/blog/02/blog-02.jpg" alt="">
                                </div>
                                <div class="blog__content blog__content-2 white-bg p-relative">
                                    <div class="blog__meta blog__meta-2 fix mb-10">
                                        <span class="f-left publisher">By <a href="https://caltms.com/">admin</a></span>
                                        <span class="f-left date"><a href="https://caltms.com/">/ august 19, 2020</a></span>
                                    </div>
                                    <h3><a href="https://caltms.com/">Fames quam parturient inter tempor facilis aenean</a></h3>
                                    <div class="blog__meta blog__meta-2">
                                        <span><a href="https://caltms.com/"><i class="fas fa-tags"></i>Couple Problem</a></span>
                                        <span><a href="https://caltms.com/"><i class="far fa-comments"></i>2 Comment</a></span>
                                    </div>
                                </div>
                            </div>
                        </div> -->
                       <!--  <div class="col-xl-4 col-lg-4 col-md-12">
                            <div class="blog__item mb-30">
                                <div class="blog__content blog__content-2 blog__sm pink-soft-bg p-relative">
                                    <div class="blog__meta blog__meta-2 fix mb-10">
                                        <span class="f-left publisher">By <a href="https://caltms.com/">admin</a></span>
                                        <span class="f-left date"><a href="https://caltms.com/">/ august 19, 2020</a></span>
                                    </div>
                                    <h3><a href="https://caltms.com/">Fames quam parturient inter tempor facilis aenean</a></h3>
                                    <div class="blog__meta blog__meta-2">
                                        <span><a href="https://caltms.com/"><i class="fas fa-tags"></i>Personal</a></span>
                                        <span><a href="https://caltms.com/"><i class="far fa-comments"></i>10 Comment</a></span>
                                    </div>
                                </div>
                            </div>
                            <div class="blog__item mb-30">
                                <div class="blog__content blog__content-2 blog__sm pink-soft-bg p-relative">
                                    <div class="blog__meta blog__meta-2 fix mb-10">
                                        <span class="f-left publisher">By <a href="https://caltms.com/">admin</a></span>
                                        <span class="f-left date"><a href="https://caltms.com/">/ august 19, 2020</a></span>
                                    </div>
                                    <h3><a href="https://caltms.com/">Praesent maurise male suada purus hendrer team</a></h3>
                                    <div class="blog__meta blog__meta-2">
                                        <span><a href="https://caltms.com/"><i class="fas fa-tags"></i>Mental</a></span>
                                        <span><a href="https://caltms.com/"><i class="far fa-comments"></i>05 Comment</a></span>
                                    </div>
                                </div>
                            </div>
                        </div> -->
                    </div>
                </div>
            </section>
            <!-- blog area end -->
        </main>
<?php
include('footer.php');
?>