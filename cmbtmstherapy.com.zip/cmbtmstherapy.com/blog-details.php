 <?php
include('header.php'); ?> 

 <main>       
            <!-- blog area start -->
            <section class="blog__area pt-60 pb-60">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-12 col-lg-12">
                            <div class="blog_details-wrapper">
                                <article class="postbox">
                                    <div class="postbox__thumb w-img">
                                        <a href="blog-details.html">
                                            <img src="assets/img/blog/blog-big-1.jpg" alt="blog image">
                                        </a>
                                    </div>
                                    <div class="postbox__content postbox__content-2 pt-40">
                                        <!-- <div class="blog__meta blog__meta-2 blog__meta-4 mb-15">
                                            <span><i class="far fa-calendar-check"></i> September 15, 2018</span>
                                            <span><a href="#"><i class="far fa-user"></i> Diboli B. Joly</a></span>
                                            <span><a href="#"><i class="far fa-comments"></i> 23 Comments</a></span>
                                        </div> -->
                                        <h1 class="postbox__title postbox__title-2">
                                            Is TMS a permanent depression treatment?
                                        </h1>
                                        <div class="postbox__text">
                                            <p>The Transcranial Magnetic Stimulation (TMS) device has stimulated the brains of tens of thousands of patients in the United States and is commonly used to treat intractable depression. Let us understand whether you or your loved ones can benefit permanently from TMS to cure your depression. </p>            
                                            <div class="inner-content">
                                                <h4> Has TMS been proven effective for depression? </h4>
                                                <p>Treatment-resistant depression is defined as a depressive episode that does not respond to previous treatment. The cost of treatment with TMS (also known as repetitive TMS or rTMS) is usually the US $300 per treatment, usually five days a week for four to six weeks. However, there is no conclusive evidence that this expensive treatment is more beneficial or effective than much cheaper and more convenient antidepressants. </p>
                                                <p> This report will examine how TMS has become a standard treatment for depression in the United States. Its effectiveness, however, has been questioned over the past decade. Although this process is atypical in several ways, the widespread use of TMS illustrates the FDA's willingness to ignore scientific evidence and its scientific advisors can lead to years of costly and problematic treatments for patients. </p>
                                            </div>
                                            <div class="inner-content">
                                                <h4> The role of TMS and FDA </h4>
                                                <p>The FDA authorized the TMS device to be commercialized under the FDA review track in 2008, which is called the de novo process.  </p>
                                            </div>
                                            <p> <strong> 1.</strong> The FDA Scientific Advisory Committee recommends not using the device submitted through 510 (k). The review process requires that the device is 'substantially equivalent' to existing medical devices on the market.  </p>
                                            <p> Since ECT and TMS mechanisms are very different, they should be based on similar benefits/risk ratios to prove substantial equivalence. Neuronetics, the first TMS NeuroStar TMS treatment system device manufacturer, submitted a double-blind, randomized, controlled clinical trial and two uncontrolled follow-up studies for the same patient for their 510(k) application.  </p>
                                             <p> <strong> 2. </strong> Clinical trials and FDA advisory committee meetings are rare for devices shipped via the 510 (k) routes. The gold standard of clinical trials is a randomized, double-blind clinical trial; patients are randomly assigned to receive treatment or a placebo. Neither the patients nor the people evaluating them know which patients have received the study treatment.  </p>
                                             <p> In 2007, the FDA advisory committee rejected TMS devices used to treat depression because they showed no benefit compared to sham treatments. Sham treatment is equivalent to placebo; its design is as close as possible to the real treatment, so the study can be randomized and double-blind. It is essential for research on treating depression because depression tends to go away over time. Therefore, a comparison of sham or placebo controls can determine whether the treatment is truly beneficial and whether there are unpleasant or dangerous side effects. </p>
                                              <p> Treatment of depression is generally assessed based on 'responder' and 'remission' status. A responder is a patient whose score on a depression severity scale (such as the Hamilton Depression Scale (HAMD) or the Montgomery Åsberg Depression Scale (MADRS)) improved by at least 50%. Remission is measured by the low score specified on the Depression Scale. The HAMD and MADRS scales involve professionals in rating patients, while the equally popular Beck Depression Scale relies on patients reporting their symptoms. However, financial conflicts of interest could interfere with objectivity when the person providing the paid treatment evaluates the effectiveness.  </p>
                                        </div>
                                    </div>
                                    <!-- second section -->
                                    <div class="postbox__content postbox__content-2">
                                        <h2 class="postbox__title postbox__title-2 mb-20">
                                          Is TMS effective?
                                        </h2>
                                        <div class="postbox__text ">
                                            <p>In the ten years since the TMS device was first approved for marketing in the United States, researchers have sought to improve its effectiveness. The treatment lasts five days a week, but studies have been conducted to evaluate the following changes in TMS to determine which changes are most effective: </p>
                                            <ul class="blog-point"> 
                                                <li> <i class="far fa-hand-point-right"></i> Frequency, treatment duration, intensity, and pulse pattern;  </li><br>
                                                <li><i class="far fa-hand-point-right"></i>  Treatment of different areas of the frontal cortex ( Left/right/dorsolateral prefrontal cortex and anterior cingulate cortex); </li><br>
                                                <li><i class="far fa-hand-point-right"></i>  Number of treatments per day;   </li><br>
                                                <li><i class="far fa-hand-point-right"></i>  Treatment weeks;  </li><br>
                                                <li><i class="far fa-hand-point-right"></i>  Types of patients suitable for treatment; and </li><br>
                                                <li><i class="far fa-hand-point-right"></i>  Maintenance for patients who have responded well to the treatment plan.  </li><br>
                                            </ul>
                                            <div class="postbox__quote">
                                                <blockquote>
                                                    <p>There is no definite effective treatment even today. For example, in a 2018 JAMA editorial commenting on a new TMS study of patients at the Veterans Affairs Medical Center, psychiatrist Charles Nemelov concluded that the lack of efficacy compared with placebo was.</p>
                                                    <footer>- "puzzling for reasons A few."</footer>
                                                </blockquote>
                                            </div>
                                           
                                            <div class="inner-content">  
                                                <p>Though this study concluded important information, there are certain limitations of it. First of all, the population in this study is consists of a lot of male participants, which contrasts with most depression clinical trials, which usually account for about two-thirds of women. Secondly, the psychological benefits of participation in clinical trials should not be underestimated. Repeated participation of the treatment team in subjects is not a neutral experience, but it is equivalent to supportive psychotherapy, if not more.  </p>
                                                <p> It is an essential negative study, but it does not fully answer the appropriate role of rTMS in treating TRD [Treatment Resistant Depression] in veterans. 15 Examining Key TMS Research Measuring the impact of treating depression is challenging since depression can improve or deteriorate based on life events, hormonal fluctuations, and other factors that may not be measured. Disorder major depressive (MDD)) </p>
                                            </div>
                                            <div class="inner-content">
                                                <h4> Does TMS have long-term benefits?  </h4>
                                                <p>It is a long-term illness that will recover over time. When patients feel very depressed, they often seek new treatments and even clinical trials. Regardless of whether they are treated, many people with depression will gradually improve over weeks and months. Certain TMS treatment reduces depression symptoms in some patients during treatment and within a few weeks after treatment. However, the effectiveness differs from individual to individual. So, there is a possibility of it being ineffective in the case of some individuals. </p>
                                                <p> Hence, further research is required to answer whether the TMS is a permanent depression treatment or not.  </p>
                                            </div>
                                        </div>
                                    </div>
                                </article>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- blog area end -->
        </main>

        <!-- footer area start -->
<?php
include('footer.php'); ?>
